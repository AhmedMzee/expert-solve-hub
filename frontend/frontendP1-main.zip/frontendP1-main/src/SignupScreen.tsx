// import React, { useState } from 'react';
// import { 
//   View, 
//   TextInput, 
//   TouchableOpacity, 
//   Text, 
//   StyleSheet, 
//   Alert,
//   KeyboardAvoidingView,
//   Platform,
//   ActivityIndicator
// } from 'react-native';
// import { useNavigation } from '@react-navigation/native';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import { StackNavigationProp } from '@react-navigation/stack';
// import api from './config/api'; // Use same API config as LoginScreen

// // Define navigation types to match LoginScreen
// type RootStackParamList = {
//   LoginScreen: undefined;
//   Signup: undefined;
//   ForgotPasswordScreen: undefined;
//   DashboardScreen: undefined;
// };

// type SignupScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Signup'>;

// const SignupScreen: React.FC = () => {
//   const navigation = useNavigation<SignupScreenNavigationProp>();
//   const [email, setEmail] = useState<string>('');
//   const [fullName, setFullName] = useState<string>('');
//   const [username, setUsername] = useState<string>('');
//   const [password, setPassword] = useState<string>('');
//   const [isLoading, setIsLoading] = useState<boolean>(false);

//   const handleSignup = async (): Promise<void> => {
//     console.log('🎯 Signup button clicked!');
//     console.log('📧 Email:', email);
//     console.log('👤 Full Name:', fullName);
//     console.log('🆔 Username:', username);
//     console.log('🔒 Password length:', password.length);

//     // Input validation
//     if (!email?.trim() || !fullName?.trim() || !username?.trim() || !password?.trim()) {
//       Alert.alert('Validation Error', 'Please fill all fields');
//       return;
//     }

//     // Email validation
//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email.trim())) {
//       Alert.alert('Validation Error', 'Please enter a valid email address');
//       return;
//     }

//     // Password length validation
//     if (password.trim().length < 6) {
//       Alert.alert('Validation Error', 'Password must be at least 6 characters long');
//       return;
//     }

//     setIsLoading(true);
    
//     try {
//       console.log('📡 Sending signup request to:', api.defaults.baseURL + '/auth/register');
      
//       const response = await api.post('/auth/register', {
//         email: email.trim().toLowerCase(),
//         fullName: fullName.trim(),
//         username: username.trim().toLowerCase(),
//         password: password.trim(),
//         userType: 'user' // Default user type
//       });

//       console.log('🎉 Signup success!', response.data);

//       Alert.alert('Success', 'Account created successfully!', [
//         { 
//           text: 'OK', 
//           onPress: () => {
//             // Clear form
//             setEmail('');
//             setFullName('');
//             setUsername('');
//             setPassword('');
            
//             // Navigate to login
//             navigation.navigate('LoginScreen');
//           }
//         }
//       ]);

//     } catch (error: unknown) {
//       console.log('💥 Signup error details:', {
//         message: (error as Error).message,
//         // @ts-ignore - accessing axios error properties
//         code: error.code,
//         // @ts-ignore
//         response: error.response?.data,
//         // @ts-ignore
//         status: error.response?.status,
//         // @ts-ignore
//         request: error.request ? 'Request made but no response' : 'No request made'
//       });

//       let errorMessage = 'Registration failed. Please try again.';
      
//       // @ts-ignore - accessing axios error properties
//       if (error.response) {
//         // @ts-ignore
//         const serverMessage = error.response.data?.message || 
//                              // @ts-ignore
//                              error.response.data?.error || 
//                              // @ts-ignore
//                              error.response.data?.msg;
        
//         // @ts-ignore
//         switch (error.response.status) {
//           case 400:
//             errorMessage = serverMessage || 'Invalid input data';
//             break;
//           case 409:
//             errorMessage = 'Email or username already exists';
//             break;
//           case 500:
//             errorMessage = 'Server error. Please try again later.';
//             break;
//           default:
//             // @ts-ignore
//             errorMessage = serverMessage || `Server error: ${error.response.status}`;
//         }
//       // @ts-ignore
//       } else if (error.request) {
//         errorMessage = 'Network error. Please check your internet connection.';
//       // @ts-ignore
//       } else if (error.code === 'ECONNABORTED') {
//         errorMessage = 'Request timeout. Please try again.';
//       } else {
//         errorMessage = (error as Error).message || 'An unexpected error occurred';
//       }

//       Alert.alert('Registration Failed', errorMessage);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const navigateToLogin = (): void => {
//     navigation.navigate('LoginScreen');
//   };

//   return (
//     <KeyboardAvoidingView
//       behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
//       style={styles.container}
//     >
//       <View style={styles.innerContainer}>
//         <Text style={styles.title}>Create Account</Text>
//         <Text style={styles.subtitle}>Join ExpertSolve Hub</Text>
        
//         <TextInput
//           style={styles.input}
//           placeholder="Email"
//           placeholderTextColor="#999"
//           onChangeText={setEmail}
//           value={email}
//           keyboardType="email-address"
//           autoCapitalize="none"
//           autoCorrect={false}
//           editable={!isLoading}
//           returnKeyType="next"
//           textContentType="emailAddress"
//         />
        
//         <TextInput
//           style={styles.input}
//           placeholder="Full Name"
//           placeholderTextColor="#999"
//           onChangeText={setFullName}
//           value={fullName}
//           autoCapitalize="words"
//           editable={!isLoading}
//           returnKeyType="next"
//           textContentType="name"
//         />
        
//         <TextInput
//           style={styles.input}
//           placeholder="Username"
//           placeholderTextColor="#999"
//           onChangeText={setUsername}
//           value={username}
//           autoCapitalize="none"
//           autoCorrect={false}
//           editable={!isLoading}
//           returnKeyType="next"
//           textContentType="username"
//         />
        
//         <TextInput
//           style={styles.input}
//           placeholder="Password (min 6 characters)"
//           placeholderTextColor="#999"
//           onChangeText={setPassword}
//           value={password}
//           secureTextEntry
//           editable={!isLoading}
//           returnKeyType="done"
//           onSubmitEditing={handleSignup}
//           textContentType="newPassword"
//         />
        
//         <TouchableOpacity 
//           style={[styles.button, isLoading && styles.disabledButton]} 
//           onPress={handleSignup}
//           disabled={isLoading}
//         >
//           {isLoading ? (
//             <View style={styles.loadingContainer}>
//               <ActivityIndicator color="#ffffff" size="small" />
//               <Text style={styles.loadingText}>Creating Account...</Text>
//             </View>
//           ) : (
//             <Text style={styles.buttonText}>Sign Up</Text>
//           )}
//         </TouchableOpacity>
        
//         <TouchableOpacity 
//           style={styles.backButton}
//           onPress={navigateToLogin}
//           disabled={isLoading}
//         >
//           <Text style={styles.backButtonText}>
//             Already have an account? <Text style={styles.backButtonTextBold}>Sign In</Text>
//           </Text>
//         </TouchableOpacity>

//         {/* Debug Info - Remove in production */}
//         {__DEV__ && (
//           <View style={styles.debugContainer}>
//             <Text style={styles.debugText}>🔧 Debug Info</Text>
//             <Text style={styles.debugText}>Server: {api.defaults.baseURL}</Text>
//             <Text style={styles.debugText}>Endpoint: /auth/register</Text>
//           </View>
//         )}
//       </View>
//     </KeyboardAvoidingView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#f8f9fa',
//   },
//   innerContainer: {
//     flex: 1,
//     justifyContent: 'center',
//     padding: 20,
//     maxWidth: 400,
//     alignSelf: 'center',
//     width: '100%',
//   },
//   title: { 
//     fontSize: 32,
//     fontWeight: 'bold',
//     marginBottom: 8,
//     textAlign: 'center',
//     color: '#2c3e50',
//   },
//   subtitle: {
//     fontSize: 16,
//     marginBottom: 30,
//     textAlign: 'center',
//     color: '#7f8c8d',
//   },
//   input: { 
//     height: 52,
//     borderColor: '#e1e8ed',
//     borderWidth: 1,
//     borderRadius: 10,
//     paddingHorizontal: 16,
//     marginBottom: 16,
//     fontSize: 16,
//     backgroundColor: 'white',
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 1 },
//     shadowOpacity: 0.05,
//     shadowRadius: 2,
//     elevation: 1,
//   },
//   button: {
//     backgroundColor: '#3498db',
//     paddingVertical: 16,
//     borderRadius: 10,
//     alignItems: 'center',
//     marginTop: 10,
//     minHeight: 52,
//     justifyContent: 'center',
//     shadowColor: '#3498db',
//     shadowOffset: { width: 0, height: 4 },
//     shadowOpacity: 0.3,
//     shadowRadius: 8,
//     elevation: 4,
//   },
//   disabledButton: {
//     backgroundColor: '#bdc3c7',
//     shadowOpacity: 0,
//     elevation: 0,
//   },
//   buttonText: {
//     color: '#ffffff',
//     fontWeight: 'bold',
//     fontSize: 18,
//   },
//   loadingContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   loadingText: {
//     color: 'white',
//     fontSize: 16,
//     fontWeight: '600',
//     marginLeft: 8,
//   },
//   backButton: {
//     marginTop: 20,
//     alignItems: 'center',
//     padding: 12,
//   },
//   backButtonText: {
//     color: '#7f8c8d',
//     fontSize: 16,
//     textAlign: 'center',
//   },
//   backButtonTextBold: {
//     color: '#3498db',
//     fontWeight: 'bold',
//   },
//   debugContainer: {
//     marginTop: 30,
//     padding: 12,
//     backgroundColor: '#34495e',
//     borderRadius: 8,
//     opacity: 0.9,
//   },
//   debugText: {
//     color: 'white',
//     fontSize: 11,
//     textAlign: 'center',
//     marginBottom: 2,
//   },
// });

// export default SignupScreen;
import React, { useState } from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { StackNavigationProp } from '@react-navigation/stack';
import api from './config/api';

type RootStackParamList = {
  LoginScreen: undefined;
  Signup: undefined;
  ForgotPasswordScreen: undefined;
  DashboardScreen: undefined;
};

type SignupScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Signup'>;

const SignupScreen: React.FC = () => {
  const navigation = useNavigation<SignupScreenNavigationProp>();
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSignup = async () => {
    if (!email.trim() || !fullName.trim() || !username.trim() || !password.trim()) {
      Alert.alert('Validation Error', 'Please fill all fields');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      Alert.alert('Validation Error', 'Please enter a valid email address');
      return;
    }

    if (password.trim().length < 6) {
      Alert.alert('Validation Error', 'Password must be at least 6 characters long');
      return;
    }

    setIsLoading(true);

    try {
      const response = await api.post('/auth/register', {
        email: email.trim().toLowerCase(),
        fullName: fullName.trim(),
        username: username.trim().toLowerCase(),
        password: password.trim(),
        userType: 'user'
      });

      Alert.alert('Success', 'Account created successfully!', [
        {
          text: 'OK',
          onPress: () => {
            setEmail('');
            setFullName('');
            setUsername('');
            setPassword('');
            navigation.navigate('LoginScreen');
          }
        }
      ]);

    } catch (error: any) {
      let errorMessage = 'Registration failed. Please try again.';
      if (error.response) {
        const serverMessage = error.response.data?.message || error.response.data?.error || error.response.data?.msg;
        switch (error.response.status) {
          case 400:
            errorMessage = serverMessage || 'Invalid input data';
            break;
          case 409:
            errorMessage = 'Email or username already exists';
            break;
          case 500:
            errorMessage = 'Server error. Please try again later.';
            break;
          default:
            errorMessage = serverMessage || `Server error: ${error.response.status}`;
        }
      } else if (error.request) {
        errorMessage = 'Network error. Please check your internet connection.';
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = 'Request timeout. Please try again.';
      } else {
        errorMessage = error.message || 'An unexpected error occurred';
      }

      Alert.alert('Registration Failed', errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const navigateToLogin = () => {
    navigation.navigate('LoginScreen');
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.innerContainer}>
        <Text style={styles.title}>Create Account</Text>
        <Text style={styles.subtitle}>Join ExpertSolve Hub</Text>

        {/* Email */}
        <View style={styles.inputWrapper}>
          <Icon name="envelope" size={18} color="#3498db" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#999"
            onChangeText={setEmail}
            value={email}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            editable={!isLoading}
          />
        </View>

        {/* Full Name */}
        <View style={styles.inputWrapper}>
          <Icon name="user" size={18} color="#3498db" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            placeholderTextColor="#999"
            onChangeText={setFullName}
            value={fullName}
            autoCapitalize="words"
            editable={!isLoading}
          />
        </View>

        {/* Username */}
        <View style={styles.inputWrapper}>
          <Icon name="id-badge" size={18} color="#3498db" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Username"
            placeholderTextColor="#999"
            onChangeText={setUsername}
            value={username}
            autoCapitalize="none"
            autoCorrect={false}
            editable={!isLoading}
          />
        </View>

        {/* Password */}
        <View style={styles.inputWrapper}>
          <Icon name="lock" size={18} color="#3498db" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Password (min 6 characters)"
            placeholderTextColor="#999"
            onChangeText={setPassword}
            value={password}
            secureTextEntry
            editable={!isLoading}
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          style={[styles.button, isLoading && styles.disabledButton]}
          onPress={handleSignup}
          disabled={isLoading}
        >
          {isLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator color="#ffffff" size="small" />
              <Text style={styles.loadingText}>Creating Account...</Text>
            </View>
          ) : (
            <Text style={styles.buttonText}>Sign Up</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.backButton} onPress={navigateToLogin} disabled={isLoading}>
          <Text style={styles.backButtonText}>
            Already have an account? <Text style={styles.backButtonTextBold}>Sign In</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  innerContainer: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    maxWidth: 400,
    alignSelf: 'center',
    width: '100%',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
    color: '#2c3e50',
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 30,
    textAlign: 'center',
    color: '#7f8c8d',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderColor: '#e1e8ed',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 16,
    paddingHorizontal: 12,
    height: 52,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#2c3e50',
  },
  button: {
    backgroundColor: '#3498db',
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    minHeight: 52,
    justifyContent: 'center',
    shadowColor: '#3498db',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  disabledButton: {
    backgroundColor: '#bdc3c7',
    shadowOpacity: 0,
    elevation: 0,
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 18,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loadingText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  backButton: {
    marginTop: 20,
    alignItems: 'center',
    padding: 12,
  },
  backButtonText: {
    color: '#7f8c8d',
    fontSize: 16,
    textAlign: 'center',
  },
  backButtonTextBold: {
    color: '#3498db',
    fontWeight: 'bold',
  },
});

export default SignupScreen;
