// import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { RootStackParamList } from './types/navigation';


// // Import your screens from 'src'
import LoginScreen from './src/LoginScreen';
import SignupScreen from './src/SignupScreen';
import DashboardScreen from './src/DashboardScreen';
import Answer from './src/Answer';
import ChangePasswordScreen from './src/ChangePasswordScreen';
import Challenges from './src/Challenges';
import Menu from './src/Menu';
import QuestionsScreen from './src/QuestionsScreen';
import SolutionScreen from './src/SolutionScreen';
import ForgotPasswordScreen from './src/ForgotPasswordScreen';
import ContactUs from './src/ContactUs';
import PrivacySettings from './src/PrivacySettings';
import SettingsScreen from './src/SettingsScreen';
import ProfileScreen from './src/ProfileScreen';
import WelcomeScreen from './src/WelcomeScreen';

const Stack = createStackNavigator();


export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Signup" component={SignupScreen} />
       <Stack.Screen name="PrivacySettings" component={PrivacySettings} />
       <Stack.Screen name="Settings" component={SettingsScreen} />
         <Stack.Screen name="ContactUs" component={ContactUs} />
          <Stack.Screen name="EditProfile" component={ContactUs} />
       <Stack.Screen name="Profile" component={ProfileScreen} />
        <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
       <Stack.Screen name="Solutions" component={SolutionScreen} />
       <Stack.Screen name="QuestionsScreen" component={QuestionsScreen} />
       <Stack.Screen name="Menu" component={Menu} />
       <Stack.Screen name="WelcomeScreen" component={WelcomeScreen} />
       <Stack.Screen name="DashboardScreen" component={DashboardScreen} />

       <Stack.Screen name="Challenges" component={Challenges} />
       <Stack.Screen name="ChangePassword" component={ChangePasswordScreen} />
        <Stack.Screen name="Answer" component={Answer} />

       
      </Stack.Navigator>
    </NavigationContainer>
  );
}
