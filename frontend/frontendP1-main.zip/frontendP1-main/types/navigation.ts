// types/navigation.ts
export type RootStackParamList = {
  Login: undefined;
  Signup: undefined;
  DashboardScreen: undefined;
  EditProfile: undefined;
  ChangePassword: undefined;
  Settings: undefined;
  ContactUs: undefined;
  PrivacySettings: undefined;
  Challenges: undefined;
  Solutions: undefined;
  ForgotPassword: undefined;
  Answer: undefined;
  Profile: undefined;
  Menu: undefined;
  WelcomeScreen:undefined;
};
