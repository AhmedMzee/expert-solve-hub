 
const pool = require('../config/database');

class Question {
  static async create(questionData) {
    const { userId, content } = questionData;
    
    const query = `
      INSERT INTO anonymous_questions (user_id, content)
      VALUES ($1, $2)
      RETURNING *
    `;
    
    const values = [userId, content];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async getAll() {
    const query = `
      SELECT question_id, content, created_at
      FROM anonymous_questions
      ORDER BY created_at DESC
    `;
    const result = await pool.query(query);
    return result.rows;
  }

  static async getById(questionId) {
    const query = `
      SELECT question_id, content, created_at
      FROM anonymous_questions
      WHERE question_id = $1
    `;
    const result = await pool.query(query, [questionId]);
    return result.rows[0];
  }

  static async getByUserId(userId) {
    const query = `
      SELECT *
      FROM anonymous_questions
      WHERE user_id = $1
      ORDER BY created_at DESC
    `;
    const result = await pool.query(query, [userId]);
    return result.rows;
  }

  static async delete(questionId, userId) {
    const query = `
      DELETE FROM anonymous_questions
      WHERE question_id = $1 AND user_id = $2
      RETURNING *
    `;
    const result = await pool.query(query, [questionId, userId]);
    return result.rows[0];
  }
}

module.exports = Question;