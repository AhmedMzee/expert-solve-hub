 
const pool = require('../config/database');

class Answer {
  static async create(answerData) {
    const { questionId, expertId, content } = answerData;
    
    const query = `
      INSERT INTO answers (question_id, expert_id, content)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    
    const values = [questionId, expertId, content];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async getByQuestionId(questionId) {
    const query = `
      SELECT a.*, u.full_name as expert_name, u.area_of_expertise
      FROM answers a
      JOIN users u ON a.expert_id = u.user_id
      WHERE a.question_id = $1
      ORDER BY a.created_at DESC
    `;
    const result = await pool.query(query, [questionId]);
    return result.rows;
  }

  static async getByExpertId(expertId) {
    const query = `
      SELECT a.*, q.content as question_content
      FROM answers a
      JOIN anonymous_questions q ON a.question_id = q.question_id
      WHERE a.expert_id = $1
      ORDER BY a.created_at DESC
    `;
    const result = await pool.query(query, [expertId]);
    return result.rows;
  }

  static async getById(answerId) {
    const query = `
      SELECT a.*, u.full_name as expert_name, u.area_of_expertise, q.content as question_content
      FROM answers a
      JOIN users u ON a.expert_id = u.user_id
      JOIN anonymous_questions q ON a.question_id = q.question_id
      WHERE a.answer_id = $1
    `;
    const result = await pool.query(query, [answerId]);
    return result.rows[0];
  }

  static async update(answerId, expertId, content) {
    const query = `
      UPDATE answers
      SET content = $1
      WHERE answer_id = $2 AND expert_id = $3
      RETURNING *
    `;
    const result = await pool.query(query, [content, answerId, expertId]);
    return result.rows[0];
  }

  static async delete(answerId, expertId) {
    const query = `
      DELETE FROM answers
      WHERE answer_id = $1 AND expert_id = $2
      RETURNING *
    `;
    const result = await pool.query(query, [answerId, expertId]);
    return result.rows[0];
  }
}

module.exports = Answer;