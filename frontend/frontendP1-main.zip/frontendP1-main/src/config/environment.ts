export const api = {
    url:'http://localhost:8080/api'
}