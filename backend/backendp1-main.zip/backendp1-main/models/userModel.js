 
const pool = require('../config/database');

class User {
  static async create(userData) {
    const { email, password, fullName, username, bio, userType, areaOfExpertise, profilePicture } = userData;
    
    const query = `
      INSERT INTO users (email, password, full_name, username, bio, user_type, area_of_expertise, profile_picture)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING user_id, email, full_name, username, bio, user_type, area_of_expertise, profile_picture, created_at
    `;
    
    const values = [email, password, fullName, username, bio, userType, areaOfExpertise, profilePicture];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async findByEmail(email) {
    const query = 'SELECT * FROM users WHERE email = $1';
    const result = await pool.query(query, [email]);
    return result.rows[0];
  }

  static async findById(userId) {
    const query = `
      SELECT user_id, email, full_name, username, bio, user_type, area_of_expertise, profile_picture, created_at 
      FROM users WHERE user_id = $1
    `;
    const result = await pool.query(query, [userId]);
    return result.rows[0];
  }

  static async getAllExperts() {
    const query = `
      SELECT user_id, email, full_name, username, bio, user_type, area_of_expertise, profile_picture, created_at 
      FROM users WHERE user_type = 'expert'
      ORDER BY created_at DESC
    `;
    const result = await pool.query(query);
    return result.rows;
  }

  static async updateProfile(userId, updateData) {
    const { fullName, username, bio, areaOfExpertise, profilePicture } = updateData;
    
    const query = `
      UPDATE users 
      SET full_name = $1, username = $2, bio = $3, area_of_expertise = $4, profile_picture = $5
      WHERE user_id = $6
      RETURNING user_id, email, full_name, username, bio, user_type, area_of_expertise, profile_picture, created_at
    `;
    
    const values = [fullName, username, bio, areaOfExpertise, profilePicture, userId];
    const result = await pool.query(query, values);
    return result.rows[0];
  }
}

module.exports = User;