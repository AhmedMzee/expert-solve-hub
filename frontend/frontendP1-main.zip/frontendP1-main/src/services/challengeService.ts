import http from '../config/http.service'
import { api } from '../config/environment'
export const ChallengeService = {

    async getChallenge(){
        return await http.get(`${api.url}/challenge/getAll`)
    }

}