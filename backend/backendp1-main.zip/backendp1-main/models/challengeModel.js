 
const pool = require('../config/database');

class Challenge {
  static async create(challengeData) {
    const { expertId, title, description } = challengeData;
    
    const query = `
      INSERT INTO challenges (expert_id, title, description)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    
    const values = [expertId, title, description];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async getAll() {
    const query = `
      SELECT c.*, u.full_name as expert_name, u.area_of_expertise
      FROM challenges c
      JOIN users u ON c.expert_id = u.user_id
      ORDER BY c.created_at DESC
    `;
    const result = await pool.query(query);
    return result.rows;
  }

  static async getById(challengeId) {
    const query = `
      SELECT c.*, u.full_name as expert_name, u.area_of_expertise
      FROM challenges c
      JOIN users u ON c.expert_id = u.user_id
      WHERE c.challenge_id = $1
    `;
    const result = await pool.query(query, [challengeId]);
    return result.rows[0];
  }

  static async getByExpertId(expertId) {
    const query = `
      SELECT c.*, u.full_name as expert_name, u.area_of_expertise
      FROM challenges c
      JOIN users u ON c.expert_id = u.user_id
      WHERE c.expert_id = $1
      ORDER BY c.created_at DESC
    `;
    const result = await pool.query(query, [expertId]);
    return result.rows;
  }

  static async createSolution(solutionData) {
    const { challengeId, expertId, content } = solutionData;
    
    const query = `
      INSERT INTO solutions (challenge_id, expert_id, content)
      VALUES ($1, $2, $3)
      RETURNING *
    `;
    
    const values = [challengeId, expertId, content];
    const result = await pool.query(query, values);
    return result.rows[0];
  }

  static async getSolutionsByChallengeId(challengeId) {
    const query = `
      SELECT s.*, u.full_name as expert_name, u.area_of_expertise
      FROM solutions s
      JOIN users u ON s.expert_id = u.user_id
      WHERE s.challenge_id = $1
      ORDER BY s.created_at DESC
    `;
    const result = await pool.query(query, [challengeId]);
    return result.rows;
  }
}

module.exports = Challenge;